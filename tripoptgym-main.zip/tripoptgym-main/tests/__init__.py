"""
TripOptGym Test Suite

Run with: pytest tests/
Run with coverage: pytest --cov=tripoptgym --cov-report=html tests/
"""
