"""Scripts package for TripOpt Gym."""

from tripoptgym.scripts.main import main

__all__ = ["main"]
