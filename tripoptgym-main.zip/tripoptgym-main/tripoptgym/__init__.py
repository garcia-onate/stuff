"""TripOpt Gym - Freight Train Optimization Environment

A reinforcement learning environment for optimizing freight train control.
"""

__version__ = "1.0.0"
__author__ = "Joe Wakeman"
